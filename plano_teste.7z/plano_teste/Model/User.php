<?php
App::uses('AppUserModel', 'Model');

class User extends AppUserModel
{
	

}
?>