<?php
App::uses('AppModel', 'Model');

class Servicos extends AppModel{
var $useTable= "servicos";

	/*
	 * Validações do Cake
	 * https://book.cakephp.org/2.0/en/models/data-validation.html#core-validation-rules
	 
	
	var $validate = array(
		'nome' => array(
			'obrigatorio' => array(
				'rule'   	=> 'money',
				'message'	=> 'digite um valor $',
				//'required' => true
			),
			'outra' => array(
				'rule'   	=> array('minLength', 3),
				'message'	=> 'Digite mais de 3 números'
			)
		),
		'nomemae' => array(
	        'rule' => array('numeric'),
	        'message' => 'somente números'
	    ),			
		'email' => array(
			'rule' => array('email'),
			'message' => 'digite um email válido'
		)
	);*/
	
}

?>