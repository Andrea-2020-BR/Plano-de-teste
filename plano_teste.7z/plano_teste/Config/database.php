<?php
class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => BD_HOST,
		'login' => BD_USER,
		'password' => BD_PASS,
		'database' => 'plano_teste',
		'prefix' => '',
		'encoding' => 'utf8',
	);

	public $global = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => BD_HOST,
		'login' => BD_USER,
		'password' => BD_PASS,
		'database' => ACL_DATABASE,
		'prefix' => '',
		'encoding' => 'utf8',
	);
}
