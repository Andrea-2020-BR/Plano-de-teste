<?php
/**
 * CakePHP Debug Level:
  */
	Configure::write('debug', 2);


	
	
	Configure::write('Error', array(
		'handler' => 'ErrorHandler::handleError',
		'level' => E_ALL & ~E_DEPRECATED,
		'trace' => true
	));


	
	Configure::write('Exception', array(
		'handler' => 'ErrorHandler::handleException',
		'renderer' => 'ExceptionRenderer',
		'log' => true
	));


	Configure::write('App.encoding', 'UTF-8');


/**
 * Session configuration.
  */
	Configure::write('Session', array(
		'defaults' => 'php'
	));

	
/**
 * A random string used in security hashing methods.
 */
	Configure::write('Security.salt', 'D1EA356091D1535705AA0DAC85D51674559AB96738DF804A721E08903346DDCD');

/**
 * A random numeric string (digits only) used to encrypt/decrypt strings.
 */
	Configure::write('Security.cipherSeed', '28339662315791334387642289168');


/**
 * The class name and database used in CakePHP's access control lists.
 */
	Configure::write('Acl.classname', 'Detran.DetranAcl');
	Configure::write('Acl.database', 'global');

/**
 * Cache Engine Configuration
 * Default settings provided below
 *
 * File storage engine.
 */
$engine = 'File';

// In development mode, caches should expire quickly.
$duration = '+999 days';
if (Configure::read('debug') > 0) {
	$duration = '+10 seconds';
}

// Prefix each application on the same server with a different string, to avoid Memcache and APC conflicts.
$prefix = 'myapp_';


Cache::config('_cake_core_', array(
	'engine' => $engine,
	'prefix' => $prefix . 'cake_core_',
	'path' => CACHE . 'persistent' . DS,
	'serialize' => ($engine === 'File'),
	'duration' => $duration
));


Cache::config('_cake_model_', array(
	'engine' => $engine,
	'prefix' => $prefix . 'cake_model_',
	'path' => CACHE . 'models' . DS,
	'serialize' => ($engine === 'File'),
	'duration' => $duration
));
