<?php
/**
 * Here, we are connecting '/' (base path) to controller called 'Pages',
 */
	Router::connect('/', array('controller' => 'Servicos', 'action' => 'index'));
/**
 * ...and connect the rest of 'Pages' controller's URLs.
 */
	Router::connect('/pages/*', array('controller' => 'pages', 'action' => 'display'));

/**
 * Load all plugin routes. See the CakePlugin documentation on
 * how to customize the loading of plugin routes.
 */
	CakePlugin::routes();


	require CAKE . 'Config' . DS . 'routes.php';
