<?php

class ListaErrosController extends AppController{

// 	/var $components = array('Detran.Filtro');	
	var $helpers = array('Detran.Excel','Detran.Tcpdf','Detran.Formatacao');
	var $uses = array('ListaErros','Servicos', 'Cenarios');
	
	
//Associar a lista de erros ao cenário. Se não houver "id" será entendido como nulo.
	function index($id = null)
	{
	    
	    $this->set('idCenario', $id);
	    
	    $buscaServicos = $this->Servicos->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Servicos.id',
	        ), 
	        'joins'=>array(
	            array(
	                'table' => 'cenarios',
	                'alias' => 'Cenarios',
	                'type' => 'LEFT',
	                'conditions' => 'Cenarios.servicos_id = Servicos.id'
	            )
	        ),
	        'conditions'=>array('Cenarios.id'=>$id)
	    ));
	    
	    $this->set('buscaServicos', $buscaServicos);
	
	    
	    $registros = $this->ListaErros->find('all',array(
			'recursive' => 0,
			'fields' => array(
				'ListaErros.id',
				'ListaErros.descricao',
			    'ListaErros.diretorio',
			    'ListaErros.extensao',
			    'ListaErros.nome_arquivo',
			    'ListaErros.cenario_id',
			    'Cenarios.servicos_id'
			),
	        'joins'=>array(
	            array(
	                'table' => 'cenarios',
	                'alias' => 'Cenarios',
	                'type' => 'LEFT',
	                'conditions' => 'Cenarios.id = ListaErros.cenario_id'
	            )
	        ),
	        
	        'conditions'=>array('ListaErros.cenario_id'=>$id)
	    ));
	    
	   // debug($registros);
	    
	    $this->set(compact('registros'));

	    
	}
	
	function adicionar($id = null){
	    
	  $this->set('idCenario', $id);
	    
	  
	    //CRIAR SCRIPT DE GRAVACAO
	    if($this->data){
	        //debug($this->data);exit();
	        $arrayListaErros = array();
	        $arrayListaErros['ListaErros']['id'] = '';
	        $arrayListaErros['ListaErros']['cenario_id'] = $this->data['ListaErros']['cenario_id'];
	        $arrayListaErros['ListaErros']['descricao'] = $this->data['ListaErros']['descricao'];
	        
	        if($this->ListaErros->save($arrayListaErros['ListaErros'])){
	            $this->Session->setFlash('<b>Cadastrado com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	            $this->redirect(array('action'=>'index/'.$this->data['ListaErros']['cenario_id']));
	        }else{
	            $this->Session->setFlash('<b> Erro ao realizar o cadastro!</b>');
	            $this->redirect(array('action'=>'index/'.$this->data['ListaErros']['cenario_id']));
	        }
	    }
	
	
	}
	
	function upload($id=null){
	     
	    $registro = $this->ListaErros->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'ListaErros.id',
	            'ListaErros.descricao',
	            'ListaErros.cenario_id',
	        ),
	        'conditions'=>array('ListaErros.id'=>$id)
	    ));
	    
	    $this->set('registro', $registro);
	    
	    
	     if($this->data){
	      /*   debug($this->data);
	        exit();  */
	        
	        //SE TEVE ARQUIVO ANEXADO
	        if (is_uploaded_file($this->data['ListaErros']['anexo']['tmp_name'])){
	            if($this->data['ListaErros']['anexo']['type'] == 'application/pdf' ||
	                $this->data['ListaErros']['anexo']['type'] == 'application/msword' ||
	                $this->data['ListaErros']['anexo']['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
	                $this->data['ListaErros']['anexo']['type'] == 'application/vnd.ms-excel' ||
	                $this->data['ListaErros']['anexo']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
	                $this->data['ListaErros']['anexo']['type'] == 'application/vnd.ms-powerpoint' || 
	                $this->data['ListaErros']['anexo']['type'] == 'application/vnd.openxmlformats-officedocument.presentationml.presentation' 
	                ){
	             
	                    if($this->data['ListaErros']['anexo']['size'] < 1024 * 1024 * 8){ // 8Mb
	                        // Pega o nome do arquivo
	                        $nome_arquivo = pathinfo ($this->data['ListaErros']['anexo']['name'], PATHINFO_FILENAME);
	                        // Pega a extensão
	                        $extensao = pathinfo ($this->data['ListaErros']['anexo']['name'], PATHINFO_EXTENSION);
	                        // Converte a extensão para minúsculo
	                        $extensao = strtolower ($extensao);
	                        $conteudo = file_get_contents($this->data['ListaErros']['anexo']['tmp_name']);
	                        
	                        $novoNome = $nome_arquivo.uniqid(_);
	                        
	                     
	                        $arrayPublicacao = array();
	                        $arrayPublicacao['ListaErros']['id'] = $this->data['ListaErros']['id'];
	                        $arrayPublicacao['ListaErros']['extensao'] = $extensao;
	                        $arrayPublicacao['ListaErros']['nome_arquivo'] = $novoNome;
	                        $arrayPublicacao['ListaErros']['diretorio'] = 'erros';
	                        
	                        /* debug($arrayPublicacao);
	                         exit(); */
	                        
	                        // Depois verifica se é possível mover o arquivo para a pasta escolhida
	                        //if (move_uploaded_file($this->data['ListaErros']['anexo']['tmp_name'], ROOT.'/app/webroot/files/'.$arrayPublicacao['ListaErros']['diretorio'].'/' . $arrayPublicacao['ListaErros']['nome_arquivo'].'.'.$arrayPublicacao['ListaErros']['extensao'])) {
	                  
	                            /*  debug($arrayPublicacao);
	                            exit(); */
	                                
	                                // Upload concluido salvar o registro no banco
	                            if($this->ListaErros->save($arrayPublicacao['ListaErros'])){
	                                $this->Session->setFlash('<b>Documento gravado com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	                                $this->redirect(array('action'=>'index/'.$this->data['ListaErros']['cenario_id']));
	                            }else{
	                                $this->Session->setFlash('<b>Erro ao gravar documento!</b>');
	                                $this->redirect(array('action'=>'index/'.$this->data['ListaErros']['cenario_id']));
	                            }
	                       /* } else {
	                            $this->Session->setFlash('<b>Erro ao gravar documento!</b>');
	                            $this->redirect(array('action'=>'index'));
	                       } */
	                    }else{
	                        $this->Session->setFlash('<b>O documento anexado não pode ultrapassar 8Mb !</b>');
	                    }
	            }else{
	                $this->Session->setFlash('<b>Erro ao anexar documento... <br/>O arquivo anexo deve possuir uma das seguintes extensões: (.ppt, .pptx, .pdf, .doc, .docx, .xls, .xlsx)</b>');
	            }
	        }else{
	              $this->Session->setFlash('<b>Documento não foi anexado!</b>');
	              $this->redirect(array('action'=>'index/'.$this->data['ListaErros']['cenario_id']));
	         
	        }
	        
	    } 
	    
	    
	}
	
	
	/*function info($id){
	        
	    //Buscando todos os registros do Cenarios
	     $Lista_Funcoes = $this->ListaErros->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'ListaErros.id',
	            'ListaErros.descricao',
	        
	       	        ),
	       	        'conditions' => array('ListaErros.id'=>$id),   
	    )); 
	    	   
	    $registros = $this->ListaErros->find('all',array(
	        'recursive' => 0,
	        'fields' => array(
	            'ListaErros.id',
	            'ListaErros.descricao',
	           
	           	        ),
	        'joins'=>array(
	            array(
	                'table' => 'servicos',
	                'alias' => 'Servicos',
	                'type' => 'LEFT',
	                'conditions' => 'Servicos.id = Cenarios.servicos_id'
	            )
	        ),
	        //'order' => array('PlanoTeste.ponto_de_entrega'=>'asc'),
	        'conditions' => array('Servicos.id'=>$id),
	        //'limit' => 1
	    ));
	    //debug($registros);exit();
	    $qtdregistros = $this->Cenarios->find('count',array('conditions' => $conditions));
	    
	    $this->set(compact('registros','qtdregistros', 'servico'));
	   	    
	}*/
	
	function remover($id, $idCenario) {
	    
	    if($this->ListaErros->delete($id)){
	        $this->Session->setFlash('<b>Cenário excluído com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	        $this->redirect(array('action'=>'index/'.$idCenario));
	        
	    }else{
	        $this->Session->setFlash('<b>Erro ao excluir!</b>');
	        $this->redirect(array('action'=>'index/'.$idCenario));
	    }
	    
	    
	}
	
	function relatorio () {
	    
	    $servicos = $this->Servicos->find('list',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao'
	        ),
	    ));
	    $this->set(compact('servicos'));
	  
	
	    
	    if($this->data){
	    
	        //criar script e query que gera o pdf
	        $erros = $this->ListaErros->find('all',array(
	            'recursive' => 0,
	            'fields' => array(
	                'ListaErros.descricao',
	                'Servicos.descricao',
	                'Cenarios.descricao'
	            ), 
	            'joins'=>array(
	                array(
	                    'table' => 'cenarios',
	                    'alias' => 'Cenarios',
	                    'type' => 'LEFT',
	                    'conditions' => 'Cenarios.id = ListaErros.cenario_id'
	                ),
	                array(
	                    'table' => 'servicos',
	                    'alias' => 'Servicos',
	                    'type' => 'LEFT',
	                    'conditions' => 'Servicos.id = Cenarios.servicos_id'
	                )
	            ),
	            
	            'conditions'=>array('ListaErros.cenario_id'=>$this->data['cenario_id'])
	        ));
	
	        $this->set('erros', $erros);
	        
	        
	    //    debug($erros);
	    //    exit();
	        
	        
	        
	        $this->layout = 'pdf';
	        $this->render("imprimir_relatorio_erros");
	                         
	    }
	    
	    
	}
	
	function buscaCenario(){
	    
	    
	    $cenarios = $this->Cenarios->find('list',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Cenarios.id',
	            'Cenarios.descricao'
	        ),
	        'conditions' => array('Cenarios.servicos_id'=>$this->data['ListaErros']['servicos_id']),
	    ));
	    $this->set(compact('cenarios'));
	   
	}
	


}




?>