<?php

class CenariosController extends AppController{

// 	/var $components = array('Detran.Filtro');
	var $helpers = array(		
		'Detran.Tcpdf',
		'Detran.Excel'		
	);
	
	var $uses = array('Cenarios', 'Servicos');

	
	
	function index($id = null){
	    
	    $this->set('servicos_id', $id);
	    $condition = "";
	    if (!empty($id)){
	        $condition = array('Cenarios.servicos_id'=>$id);
	    }
	    
	    $servicos = $this->Servicos->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao',
	            'Servicos.casos_testes_id',
	        ),
	        'conditions' => array('Servicos.id'=>$id),
	    ));
	    
	    //Buscar todos os cenários cadastrados 
	    $registros = $this->Cenarios->find('all',array(
			'recursive' => 0,
			'fields' => array(
				'Cenarios.id',
				'Cenarios.descricao',
			    'Cenarios.status',
			    'Cenarios.servicos_id',
			    'Servicos.descricao',
			    'Cenarios.data',
			),
	        'joins'=>array(
	            array(
	                'table' => 'servicos',
	                'alias' => 'Servicos',
	                'type' => 'LEFT',
	                'conditions' => 'Servicos.id = Cenarios.servicos_id' 
	            )
	        ),
			//'order' => array('PlanoTeste.ponto_de_entrega'=>'asc'),
			'conditions' => $condition,
			//'limit' => 1
		));
		//debug($registros);exit();
	    $qtdregistros = $this->Cenarios->find('count',array(/*'conditions' => $conditions*/));

		$this->set(compact('registros','qtdregistros','servicos'));
	}
	function adicionar($id = null){
	    
	    /*$buscaServiços =  $this->Servicos->find('list', array(
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao',
	        ),
	        'recursive'=> -1,
	    ));
	    $this->set('servicos', $buscaServiços);*/
	    
	    $this->set('servicos_id', $id);
	    
	    $servicos = $this->Servicos->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao',
	        ),
	        'conditions' => array('Servicos.id'=>$id),
	    ));
	    $this->set('servicos', $servicos);
	    if($this->data){
	        
	     /*debug($this->data);
	        exit();*/  
	        $arrayCenarios = array();
	        $arrayCenarios['Cenarios']['id'] = '';
	        $arrayCenarios['Cenarios']['descricao'] = $this->data['Cenarios']['descricao'];
	        $arrayCenarios['Cenarios']['servicos_id'] = $this->data['Cenarios']['servicos_id'];
	        $arrayCenarios['Cenarios']['status'] = "EA";
	        $arrayCenarios['Cenarios']['procedimento'] = $this->data['Cenarios']['procedimento'];
	        $arrayCenarios['Cenarios']['observacoes'] = $this->data['Cenarios']['observacoes'];
	       /*debug($arrayCenarios);
	        exit();*/
	        
	        if($this->Cenarios->save($arrayCenarios['Cenarios'])){
	            $this->Session->setFlash('<b>Cenário cadastrado com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	            $this->redirect(array('action'=>'index/'.$this->data['Cenarios']['servicos_id']));
	        }else{
	            $this->Session->setFlash('<b>Erro ao cadastrar cenário!</b>');
	            $this->redirect(array('action'=>'index/'.$this->data['Cenarios']['servicos_id']));
	        }
	        
	       
	    }
	    
	}
	
	function alterar($id=null){
	   
	    $buscaServicos =  $this->Servicos->find('list', array(
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao',
	        ),
	        'recursive'=> -1,
	    ));
	    $this->set('servicos', $buscaServicos);
	    
	    $registro = $this->Cenarios->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Cenarios.id',
	            'Cenarios.descricao',
	            'Cenarios.servicos_id',
	            'Servicos.descricao',
	            'Cenarios.procedimento',
	            'Cenarios.observacoes',
	            
	        ),
	        'joins'=>array(
	            array(
	                'table' => 'servicos',
	                'alias' => 'Servicos',
	                'type' => 'LEFT',
	                'conditions' => 'Servicos.id = Cenarios.servicos_id'
	            )
	        ),
	        'conditions' => array('Cenarios.id'=>$id)
	    ));	    
	    $this->set('registro', $registro);
	    
	    
	   // debug($registro);
	    
	    if($this->data){
	        
	       /*  debug($this->data);
	         exit();  */
	         
	         $arrayCenarios = array();
	         $arrayCenarios['Cenarios']['id'] = $this->data['Cenarios']['id'];
	         $arrayCenarios['Cenarios']['descricao'] = $this->data['Cenarios']['descricao'];
	         $arrayCenarios['Cenarios']['servicos_id'] = $this->data['Cenarios']['servicos_id'];
	         $arrayCenarios['Cenarios']['procedimento'] = $this->data['Cenarios']['procedimento'];
	         $arrayCenarios['Cenarios']['observacoes'] = $this->data['Cenarios']['observacoes'];
	         
	         if($this->Cenarios->save($arrayCenarios['Cenarios'])){
	             $this->Session->setFlash('<b>Cenário alterado com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	             $this->redirect(array('action'=>'index/'.$this->data['Cenarios']['servicos_id']));
	         }else{
	             $this->Session->setFlash('<b>Erro ao alterar cenário!</b>');
	             $this->redirect(array('action'=>'index/'.$this->data['Cenarios']['servicos_id']));
	         }
	         
	    }
	
	}
	
	function remover($id, $idServico) {
	    $registro = $this->Cenarios->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Cenarios.id',
	            'Cenarios.status',
	        ),
	        'conditions' => array('Cenarios.id'=>$id)
	    ));	  
	    
	    
	    if($registro['Cenarios']['status'] == 'EA'){
	        
    	    if($this->Cenarios->delete($id)){  
    	        $this->Session->setFlash('<b>Cenário excluído com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
    	        $this->redirect(array('action'=>'index/'.$idServico));
    	    }else{
    	        $this->Session->setFlash('<b>Erro ao excluir!</b>');
    	        $this->redirect(array('action'=>'index/'.$idServico));
    	        
    	    }
	    
	    }else{
	        $this->Session->setFlash('<b>Cenário não pode ser removido após aprovado ou reprovado!</b>');
	        $this->redirect(array('action'=>'index/'.$idServico));
	    }
	    
	    
	}
	
	function aprovar($id, $idServico){
	    
	    $arrayCenarios=array();
	    
	    $arrayCenarios['Cenarios']['id']=$id;
	    //debug(date("Y-m-d H:i:s"));exit();
	    
	    $arrayCenarios['Cenarios']['status']='A';
	    $arrayCenarios['Cenarios']['data']= date("Y-m-d H:i:s");
	    //debug($arrayCenarios);exit();
	    
	    if($this->Cenarios->save($arrayCenarios['Cenarios'])){
	        
	        $this->Session->setFlash('<b>Cenário aprovado com sucesso!</b>', 'default', array(
	            
	            'class' => 'alert-success'
	            
	        ), 'success');
	        
	        $this->redirect(array(
	            
	            'action' => 'index/'.$idServico
	            
	        ));
	        
	    }else{
	        
	        $this->Session->setFlash('<b>Ocorreu um erro ao aprovar o Cenário</b>');
	        
	        // $this->redirect(array('action'=>'index'));
	        
	    }
	    
	}
	
	function reprovar($id, $idServico){
	    
	    $arrayCenarios=array();
	    
	    $arrayCenarios['Cenarios']['id']=$id;
	    //debug(date("Y-m-d H:i:s"));exit();
	    
	    $arrayCenarios['Cenarios']['status']='R';
	    $arrayCenarios['Cenarios']['data']= date("Y-m-d H:i:s");
	    //debug($arrayCenarios);exit();
	    
	    if($this->Cenarios->save($arrayCenarios['Cenarios'])){
	        
	        $this->Session->setFlash('<b>Cenário reprovado!</b>', 'default', array(
	            
	            'class' => 'alert-success'
	            
	        ), 'success');
	        
	        $this->redirect(array(
	            
	            'action' => 'index/'.$idServico
	            
	        ));
	        
	    }else{
	        
	        $this->Session->setFlash('<b>Ocorreu um erro ao reprovar o Cenário</b>');
	        
	        // $this->redirect(array('action'=>'index'));
	        
	    }
	    
	}
	
	
}

?>