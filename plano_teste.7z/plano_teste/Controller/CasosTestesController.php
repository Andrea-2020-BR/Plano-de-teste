<?php

class CasosTestesController extends AppController{

// 	/var $components = array('Detran.Filtro');
	var $helpers = array(		
		'Detran.Tcpdf',
		'Detran.Excel'		
	);
	//Declarar os nomes dos models (antes é necessário declarar como "model").
	
	var $uses = array('CasosTestes','Servicos');
	
	

	function index()
	{
	    $registros = $this->CasosTestes->find('all',array(
			'recursive' => 0,
			'fields' => array(
				'CasosTestes.id',
				'CasosTestes.descricao',
							    							),
	        
	        'order' => array(
	            'CasosTestes.descricao',
	        ),	        
	    ));
	    
	    //Inserir contador. Criação da variável qtdregistros (quantificar) e registros (armazenar) para contar os cenarios.
	    
	    $qtdregistros = $this->CasosTestes->find('count',array(/*'conditions' => $conditions*/));
	       
		$this->set(compact('registros','qtdregistros'));
	}
	
	function adicionar(){
	   
	    //CRIAR SCRIPT DE GRAVACAO
	    if($this->data){
	      //debug($this->data);
	        $arrayCasosTestes = array();
	        $arrayCasosTestes['CasosTestes']['id'] = '';
	        $arrayCasosTestes['CasosTestes']['descricao'] = $this->data['CasosTestes']['descricao'];
	        
	        if($this->CasosTestes->save($arrayCasosTestes['CasosTestes'])){
	            $this->Session->setFlash('<b>Caso de Teste cadastrado com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	            $this->redirect(array('action'=>'index'));
	        }else{
	            $this->Session->setFlash('<b>Erro ao cadastrar Caso de Teste!</b>');
	            $this->redirect(array('action'=>'index'));
	        }
	    }
	
	
	}
	
	function info($id){
	        
	    //Buscando todos os registros do Cenarios
	    $casosTestes = $this->CasosTestes->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'CasosTestes.id',
	            'CasosTestes.descricao',
	        
	       	        ),
	       	        'conditions' => array('CasosTestes.id'=>$id),   
	    ));
	    	   
	    $registros = $this->Servicos->find('all',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao',
	            'Servicos.casos_testes_id',
	            'CasosTestes.descricao',     
	            
	        ),
	        'joins'=>array(
	            array(
	                'table' => 'casos_testes',
	                'alias' => 'CasosTestes',
	                'type' => 'LEFT',
	                'conditions' => 'CasosTestes.id = Servicos.casos_testes_id'
	            )
	        ),
	        //'order' => array('PlanoTeste.ponto_de_entrega'=>'asc'),
	        'conditions' => array('CasosTestes.id'=>$id),
	        //'limit' => 1
	    ));
	    //debug($registros);exit();
	    $qtdregistros = $this->Servicos->find('count',array(/*'conditions' => $conditions*/));
	    
	    $this->set(compact('registros','qtdregistros', 'casosTestes'));
	    
	}
	
	function inplaceeditorAjax()
	{
	    /*
	     echo 'nome coluna: ' . $this->data['name'];
	     echo '<br>valor: ' . $this->data['value'];
	     echo '<br>primary key: ' . $this->data['pk'];
	     exit();
	     */
	    
	    $this->CasosTestes->id = $this->data['pk'];
	    if (!$this->CasosTestes->saveField($this->data['name'], $this->data['value'], true)) //true indica que deve fazer validacao antes de salvar
	        $retorno = array('sucesso'=>false, 'msg'=>MSG_ERRO_UPDATE);
	        else
	            $retorno = array('sucesso'=>true);
	            
	            echo json_encode($retorno);
	            exit();
	}
	
	
}

?>