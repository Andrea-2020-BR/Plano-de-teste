<?php

class RelatoriosController extends AppController{

// 	/var $components = array('Detran.Filtro');
	var $helpers = array(		
		'Detran.Tcpdf',
		'Detran.Excel'		
	);
	
	var $uses = array('Servicos', 'CasosTestes');
	
	function imprimir_relatorio_casos_testes($id){
	    
	    /*Busca dos dados*/
	   
	    $servicos = $this->CasosTestes->find('all',array(  /* Filtrar somente as buscas do id do CasoTestes*/
	     'recursive' => 0,
	     'fields' => array(
	       'CasosTestes.id',
	       'CasosTestes.descricao',
	         'count(Servicos.id) as totalServicos',
	        

	     ),
	        
	        'joins' => array(
	            array(
	                
	            'table'=> 'servicos',
	            'alias'=> 'Servicos',
	            'type'=> 'inner',
	            'conditions'=> 'Servicos.casos_testes_id=CasosTestes.id'
	            
	            ), 
	        ),
	        'condition' => array(
	            'CasosTestes.id = '.$id,
	        ),
	        'group' => array(
	            'CasosTestes.id',
	        ),
	        
	    ));
	    
	    $cenarios = $this->CasosTestes->find('all',array(  /* Filtrar somente as buscas do id do CasoTestes*/
	        'recursive' => 0,
	        'fields' => array(
	            'count(Cenarios.id) as totalCenarios',
	            
	            
	        ),
	        
	        'joins' => array(
	            array(
	                
	                'table'=> 'servicos',
	                'alias'=> 'Servicos',
	                'type'=> 'inner',
	                'conditions'=> 'Servicos.casos_testes_id=CasosTestes.id'
	                
	            ),
	            
	            array(
	                
	                'table'=> 'cenarios',
	                'alias'=> 'Cenarios',
	                'type'=> 'inner',
	                'conditions'=> 'Cenarios.servicos_id=Servicos.id'
	                
	            )
	        ),
	        'condition' => array(
	            'CasosTestes.id = '.$id,
	        ),
	        'group' => array(
	            'CasosTestes.id',
	        ),
	        
	    ));
	    
	    $listastatus = $this->CasosTestes->find('all',array(  /* Filtrar somente as buscas do id do CasoTestes*/
	        'recursive' => 0,
	        'fields' => array(
	            'Cenarios.id',
	            'Cenarios.status'
	        ),
	        
	        'joins' => array(
	            array(
	                
	                'table'=> 'servicos',
	                'alias'=> 'Servicos',
	                'type'=> 'inner',
	                'conditions'=> 'Servicos.casos_testes_id=CasosTestes.id'
	                
	            ),
	            
	            array(
	                
	                'table'=> 'cenarios',
	                'alias'=> 'Cenarios',
	                'type'=> 'inner',
	                'conditions'=> 'Cenarios.servicos_id=Servicos.id'
	                
	            )
	        ),
	        'condition' => array(
	            'CasosTestes.id = '.$id,
	        ),
	        
	    ));
	    
	    $qtdAprovado=0;
	    $qtdReprovado=0;
	    $qtdEmAndamento=0;
	    foreach ($listastatus as $cenario){
	        if ($cenario['Cenarios']['status'] =='A'){
	            $qtdAprovado++;
	        }
	        if ($cenario['Cenarios']['status'] =='R'){
	            $qtdReprovado++;
	        }
	        if ($cenario['Cenarios']['status'] =='EA'){
	            $qtdEmAndamento++;
	        }
	    }
	    
	    $this->set(compact('servicos','cenarios','listastatus','qtdAprovado','qtdReprovado','qtdEmAndamento' ));
	    
	    
	    
	    
	    $this->layout = 'pdf';
	    
	    $this->render("imprimir_relatorio_casos_testes");
	    
	    
	}
	
	
}
?>