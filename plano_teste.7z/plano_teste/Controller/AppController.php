<?php
App::uses('Controller', 'Controller');

class AppController extends Controller 
{
	var $app_name	= "Plano de Teste";
	
	var $actionPath = "servicos/";
	
	var $components = array('RequestHandler', 'Auth', 'Acl',  'Session', 'Detran.Filtro', 'Detran.Util');	
	/*
	 * Alguns Helpers já são carregados automaticamente no Detran.UtilComponent
	 * Html, Form, Session, Paginator, Js => array('Jquery') e Detran.Util
	 */
	//var $helpers 	= array('Js' => array('Jquery'));	
	
	//Itens do menu da página da web. Devem ser criados tb no banco com letra minuscula e _.
	var $menu = array(
	    'Casos de Teste'	=> 'CasosTestes/index',
		//'Serviços'	=> 'Servicos/index',
	    //'Cenários'	=> 'Cenarios/index',
	   
	    'Lista de Erros' => 'ListaErros/relatorio',
	        
			    
	);
	
	   
	
	function beforeRender(){		
		if (!$this->Auth->loggedIn()){			
			//Header("Location: " . $this->Auth->logoutRedirect);			
			//exit();
		}
		
		if($this->RequestHandler->isAjax() || $this->RequestHandler->isXml()) {
			Configure::write('debug', 0);
		}	
	}
	
	
	function beforeFilter(){
		$this->Auth->allow();		
		//$this->Util->buildAcl($this->actionPath);
	}
	
}