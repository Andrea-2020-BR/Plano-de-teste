<?php

class ServicosController extends AppController{

// 	/var $components = array('Detran.Filtro');
	var $helpers = array(		
		'Detran.Tcpdf',
		'Detran.Excel'		
	);
	
	var $uses = array('Servicos','Cenarios', 'CasosTestes');
	
	
//Associar o servico ao caso de teste. Se não houver "id" será entendido como nulo.
	function index($id = null)
	{
	    $condition = "";
	    if (!empty($id)){
	    $condition = array('Servicos.casos_testes_id'=>$id);
	    }
	    $registros = $this->Servicos->find('all',array(
			'recursive' => 0,
			'fields' => array(
				'Servicos.id',
				'Servicos.descricao',
			),
	        'conditions' => $condition,   
	    ));
	    
	  
	    $casostestes = $this->CasosTestes->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'CasosTestes.id',
	            'CasosTestes.descricao',
	        ),
	        'conditions' => array('CasosTestes.id'=>$id),
	    ));
	
    
	    //Adicionar um contador para cada caso de teste inserido no sistema.
	   // Criação de variaveis: quantidade Cenários e auxiliar
	   	    $aux=0;
	   	    
	    foreach ($registros as $registro){
	        $quantidadeCenarios = $this->Cenarios->find('first',array(
	            'recursive' => 0,
	            'fields' => array(
	                'count(Cenarios.id) as quantidade',
	             ),   
	            'conditions'=> array('Cenarios.servicos_id = '. $registro['Servicos']['id']),
	            'group' => array('Cenarios.servicos_id')
	        ));
	        
	        //Para cada campo vazio, inserir zero.
	        
	        if (!empty($quantidadeCenarios[0]['quantidade'])) {
	            $registros[$aux]['Servicos']['quantidade']= $quantidadeCenarios[0]['quantidade'];
	        }else {
	            $registros[$aux]['Servicos']['quantidade']= 0;
	        }
	        //debug($quantidadeCenarios[0]['quantidade']);
	        $aux++;
	    }
	   
	    //Inserir contador. Criação da variável qtdregistros (quantificar) e registros (armazenar) para contar os cenarios.
	    
	    $qtdregistros = $this->Servicos->find('count',array(/*'conditions' => $conditions*/));
	       
	    $this->set(compact('registros','qtdregistros','casostestes'));
	}
	
	function adicionar(){
	   
	    //CRIAR SCRIPT DE GRAVACAO
	    
	    $buscacasosdetestes =  $this->CasosTestes->find('list', array(
	        'fields' => array(
	            'CasosTestes.id',
	            'CasosTestes.descricao',
	        ),
	        'recursive'=> -1,
	    ));
	    $this->set('casostestes', $buscacasosdetestes);
	    if($this->data){
	        debug($this->data);
	        $arrayServicos = array();
	        $arrayServicos['Servicos']['id'] = '';
	        $arrayServicos['Servicos']['descricao'] = $this->data['Servicos']['descricao'];
	        $arrayServicos['Servicos']['casos_testes_id'] = $this->data['Servicos']['casos_testes_id'];
	        if($this->Servicos->save($arrayServicos['Servicos'])){
	            $this->Session->setFlash('<b>Serviços cadastrado com sucesso!</b>', 'default', array('class'=>'alert-success'), 'success');
	            $this->redirect(array('action'=>'index'));
	        }else{
	            $this->Session->setFlash('<b>Erro ao cadastrar serviços!</b>');
	            $this->redirect(array('action'=>'index'));
	        }
	    }
	
	
	}
	
	function info($id){
	        
	    //Buscando todos os registros do Cenarios
	    $servico = $this->Servicos->find('first',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Servicos.id',
	            'Servicos.descricao',
	        
	       	        ),
	       	        'conditions' => array('Servicos.id'=>$id),   
	    ));
	    	   
	    $registros = $this->Cenarios->find('all',array(
	        'recursive' => 0,
	        'fields' => array(
	            'Cenarios.id',
	            'Cenarios.descricao',
	            'Cenarios.servicos_id',
	            'Servicos.descricao',
	            'Cenarios.status',
	            'Cenarios.observacoes',
	        ),
	        'joins'=>array(
	            array(
	                'table' => 'servicos',
	                'alias' => 'Servicos',
	                'type' => 'LEFT',
	                'conditions' => 'Servicos.id = Cenarios.servicos_id'
	            )
	        ),
	        //'order' => array('PlanoTeste.ponto_de_entrega'=>'asc'),
	        'conditions' => array('Servicos.id'=>$id),
	        //'limit' => 1
	    ));
	    //debug($registros);exit();
	    $qtdregistros = $this->Cenarios->find('count',array(/*'conditions' => $conditions*/));
	    
	    $this->set(compact('registros','qtdregistros', 'servico'));
	    
	}
	
	
	function inplaceeditorAjax()
	{
	    /*
	     echo 'nome coluna: ' . $this->data['name'];
	     echo '<br>valor: ' . $this->data['value'];
	     echo '<br>primary key: ' . $this->data['pk'];
	     exit();
	     */
	    
	    $this->Servicos->id = $this->data['pk'];
	    if (!$this->Servicos->saveField($this->data['name'], $this->data['value'], true)) //true indica que deve fazer validacao antes de salvar
	        $retorno = array('sucesso'=>false, 'msg'=>MSG_ERRO_UPDATE);
	        else
	            $retorno = array('sucesso'=>true);
	            
	            echo json_encode($retorno);
	            exit();
	}
	
	
	
	
	
}

?>